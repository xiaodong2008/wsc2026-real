<script setup>
import { computed, onMounted, ref } from 'vue'
import { FRAMES } from '../lib/frames.js'

const designId = ref('bands')
const ratio = ref('normal')
const hint = ref('')
const canvas = ref(null)
let userImg = null
let frameImg = null
let frameSeq = 0

const design = computed(() => FRAMES.find((item) => item.id === designId.value))

function drawCover(ctx, img, width, height) {
  const scale = Math.max(width / img.width, height / img.height)
  const w = img.width * scale
  const h = img.height * scale
  ctx.drawImage(img, (width - w) / 2, (height - h) / 2, w, h)
}

function redraw() {
  if (!frameImg || !canvas.value) return
  const width = frameImg.naturalWidth
  const height = frameImg.naturalHeight
  const ctx = canvas.value.getContext('2d')
  canvas.value.width = width
  canvas.value.height = height
  ctx.clearRect(0, 0, width, height)
  if (userImg) drawCover(ctx, userImg, width, height)
  ctx.drawImage(frameImg, 0, 0, width, height)
}

async function loadFrame() {
  const src = ratio.value === 'wide' ? design.value.wide : design.value.normal
  if (!src) return
  const mine = ++frameSeq
  const img = new Image()
  img.src = src
  await img.decode()
  if (mine !== frameSeq) return
  frameImg = img
  redraw()
}

function selectDesign(id) {
  const frame = FRAMES.find((item) => item.id === id)
  designId.value = id
  if (ratio.value === 'normal' && !frame.normal) ratio.value = 'wide'
  if (ratio.value === 'wide' && !frame.wide) ratio.value = 'normal'
  loadFrame()
}

function selectRatio(next) {
  if (next === 'normal' && !design.value.normal) return
  if (next === 'wide' && !design.value.wide) return
  ratio.value = next
  loadFrame()
}

function onFile(event) {
  const file = event.target.files?.[0]
  if (!file) return
  const img = new Image()
  img.onload = () => {
    userImg = img
    URL.revokeObjectURL(img.src)
    redraw()
  }
  img.src = URL.createObjectURL(file)
  event.target.value = ''
}

function stamp14() {
  const date = new Date()
  const pad = (n) => String(n).padStart(2, '0')
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`
}

function fileName() {
  return `worldskills-shanghai-2026-${stamp14()}.png`
}

function toBlob() {
  return new Promise((resolve) => canvas.value.toBlob(resolve, 'image/png'))
}

async function downloadBlob(blob) {
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = fileName()
  link.click()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}

async function onDownload() {
  const blob = await toBlob()
  if (blob) await downloadBlob(blob)
}

async function onShare() {
  const blob = await toBlob()
  if (!blob) return
  const file = new File([blob], fileName(), { type: 'image/png' })
  if (navigator.canShare?.({ files: [file] })) {
    try {
      await navigator.share({
        title: 'WorldSkills Shanghai 2026',
        text: 'My conference photo souvenir!',
        files: [file],
      })
    } catch (err) {
      if (err.name === 'AbortError') {
        hint.value = 'Sharing was not completed. Use Download to save the image.'
        return
      }
      await downloadBlob(blob)
    }
  } else {
    await downloadBlob(blob)
  }
}

onMounted(loadFrame)
</script>

<template>
  <section>
    <label class="pick">
      Choose photo
      <input data-testid="photo-upload" type="file" accept="image/*" @change="onFile" />
    </label>
    <canvas ref="canvas"></canvas>
    <h2>Frame</h2>
    <div class="choices">
      <button v-for="frame in FRAMES" :key="frame.id" type="button" :class="{ on: designId === frame.id }" @click="selectDesign(frame.id)">{{ frame.label }}</button>
    </div>
    <h2>Ratio</h2>
    <div class="choices">
      <button type="button" data-testid="ratio-normal" :disabled="!design.normal" :class="{ on: ratio === 'normal' }" @click="selectRatio('normal')">Normal</button>
      <button type="button" data-testid="ratio-wide" :disabled="!design.wide" :class="{ on: ratio === 'wide' }" @click="selectRatio('wide')">Wide</button>
    </div>
    <div class="actions">
      <button type="button" data-testid="download-btn" @click="onDownload">Download</button>
      <button type="button" data-testid="share-btn" @click="onShare">Share</button>
    </div>
    <p v-if="hint">{{ hint }}</p>
  </section>
</template>

<style scoped>
.pick { display: grid; gap: 6px; font-weight: 700; }
canvas { max-width: 100%; height: auto; display: block; margin: 12px 0; background: #e8edf5; }
h2 { font-size: 14px; margin: 12px 0 8px; }
.choices, .actions { display: flex; flex-wrap: wrap; gap: 8px; }
button { border: 0; background: #fff; border-radius: 999px; padding: 8px 12px; }
button.on { background: #2563eb; color: #fff; }
button:disabled { opacity: .4; cursor: not-allowed; }
.actions button { background: #142033; color: #fff; }
</style>
