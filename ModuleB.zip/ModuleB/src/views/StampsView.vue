<script setup>
import { onMounted, ref } from 'vue'
import { loadJSON } from '../lib/data.js'
import { codeOf, loadCollected, saveCollected } from '../lib/stamps.js'
import { errorMessage } from '../lib/ui.js'

const sessions = ref([])
const collected = ref(loadCollected())
const code = ref('')
const justId = ref('')

function dayOf(n) {
  return Math.floor((n - 1) / 4) + 1
}

async function onCollect() {
  const typed = code.value.trim().toLowerCase()
  const hit = sessions.value.find((session) => codeOf(session) === typed)
  if (!hit) {
    errorMessage.value = 'Incorrect attendance code. Please try again.'
    return
  }
  if (collected.value.has(hit.id)) {
    errorMessage.value = 'You already collected this stamp.'
    return
  }
  const next = new Set(collected.value)
  next.add(hit.id)
  collected.value = next
  saveCollected(next)
  justId.value = hit.id
  errorMessage.value = ''
  code.value = ''
}

onMounted(async () => {
  errorMessage.value = ''
  const data = await loadJSON('api/schedule.json', 'Could not load the schedule. Please try again.')
  if (data) sessions.value = data
})
</script>

<template>
  <section>
    <header class="progress">
      <h1>Attendance Stamps</h1>
      <p>{{ collected.size }} out of 16</p>
      <progress max="16" :value="collected.size"></progress>
    </header>
    <form class="entry" @submit.prevent="onCollect">
      <label>
        Enter attendance code
        <input v-model="code" autocomplete="off" />
      </label>
      <button type="submit">Collect</button>
    </form>
    <ol class="grid">
      <li v-for="n in 16" :key="n" class="stamp" :class="{ got: collected.has(String(n)), just: justId === String(n) }">
        <img :src="`stamps/${n}.png`" :alt="`Stamp ${n}`" />
        <span v-if="justId === String(n)" class="ribbons" aria-hidden="true"></span>
        <span>#{{ n }} · Day {{ dayOf(n) }}</span>
      </li>
    </ol>
  </section>
</template>

<style scoped>
h1 { font-size: 22px; margin: 0; }
.progress p { margin: 6px 0; }
progress { width: 100%; height: 12px; }
.entry {
  position: sticky;
  top: 0;
  z-index: 5;
  display: flex;
  gap: 8px;
  align-items: end;
  padding: 10px 0;
  background: #f6f7fb;
}
label { display: grid; gap: 4px; font-size: 13px; font-weight: 650; flex: 1; }
input { border: 1px solid #cbd5e1; border-radius: 10px; padding: 10px; background: #fff; }
.entry button { border: 0; background: #2563eb; color: #fff; border-radius: 10px; padding: 10px 14px; }
.grid { list-style: none; padding: 0; margin: 12px 0 0; display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.stamp { position: relative; text-align: center; }
.stamp img { width: 100%; aspect-ratio: 1; object-fit: contain; opacity: .35; }
.stamp.got img { opacity: 1; }
.stamp.just img { animation: stamp-pop .6s cubic-bezier(.34, 1.56, .64, 1); }
.ribbons, .ribbons::before, .ribbons::after {
  position: absolute;
  left: 50%;
  top: 30%;
  width: 8px;
  height: 18px;
  background: #f43f5e;
  animation: ribbon .7s ease-out forwards;
}
.ribbons::before, .ribbons::after { content: ""; background: #facc15; }
.ribbons::before { transform: translateX(-16px); }
.ribbons::after { transform: translateX(16px); background: #22c55e; }
@keyframes stamp-pop {
  0% { transform: scale(2.2); opacity: 0; }
  60% { transform: scale(.92); opacity: 1; }
  100% { transform: scale(1); }
}
@keyframes ribbon {
  to { transform: translateY(-28px); opacity: 0; }
}
@media (min-width: 768px) {
  .grid { grid-template-columns: repeat(4, 1fr); }
}
@media (prefers-reduced-motion: reduce) {
  .stamp.just img, .ribbons, .ribbons::before, .ribbons::after { animation: none; }
}
</style>
