<script setup>
import { computed, onMounted, ref } from 'vue'
import RoomDot from '../components/RoomDot.vue'
import { loadJSON } from '../lib/data.js'
import { codeOf } from '../lib/stamps.js'
import { errorMessage } from '../lib/ui.js'

const sessions = ref([])
const mode = ref('sessions')
const day = ref(1)
const screen = ref('list')
const current = ref(null)

const daySessions = computed(() => sessions.value.filter((item) => item.day === day.value))

const speakers = computed(() => {
  const grouped = new Map()
  for (const session of sessions.value) {
    if (!grouped.has(session.speaker)) {
      grouped.set(session.speaker, {
        name: session.speaker,
        photo: `speakers/${session.speaker.toLowerCase().replaceAll(' ', '-')}.jpg`,
        sessions: [],
      })
    }
    grouped.get(session.speaker).sessions.push(session)
  }
  return [...grouped.values()].filter((speaker) => speaker.sessions.some((item) => item.day === day.value))
})

function openSession(session) {
  current.value = session
  screen.value = 'session'
}

function openSpeaker(speaker) {
  current.value = speaker
  screen.value = 'speaker'
}

function back() {
  screen.value = 'list'
  current.value = null
}

function sessionsOnDay(speaker) {
  return speaker.sessions.filter((item) => item.day === day.value)
}

onMounted(async () => {
  errorMessage.value = ''
  const data = await loadJSON('api/schedule.json', 'Could not load the schedule. Please try again.')
  if (data) sessions.value = data
})
</script>

<template>
  <section>
    <div class="switch" role="tablist">
      <button type="button" :class="{ on: mode === 'sessions' }" @click="mode = 'sessions'; back()">Sessions</button>
      <button type="button" :class="{ on: mode === 'speakers' }" @click="mode = 'speakers'; back()">Speakers</button>
    </div>
    <div class="days">
      <button v-for="n in 4" :key="n" type="button" :class="{ on: day === n }" @click="day = n; back()">Day {{ n }}</button>
    </div>

    <div v-if="screen === 'list' && mode === 'sessions'" data-testid="schedule-list" class="list">
      <button v-for="session in daySessions" :key="session.id" type="button" class="row" @click="openSession(session)">
        <strong>{{ session.title }}</strong>
        <span>{{ session.speaker }}</span>
        <span>{{ session.time }}–{{ session.endTime }}</span>
        <span class="where"><RoomDot :room="session.room" /> {{ session.roomName }}</span>
      </button>
    </div>

    <div v-else-if="screen === 'list'" class="speakers">
      <button v-for="speaker in speakers" :key="speaker.name" type="button" class="person" @click="openSpeaker(speaker)">
        <img :src="speaker.photo" :alt="speaker.name" />
        <div>
          <strong>{{ speaker.name }}</strong>
          <p v-for="session in sessionsOnDay(speaker)" :key="session.id">
            {{ session.title }} <RoomDot :room="session.room" />
          </p>
        </div>
      </button>
    </div>

    <article v-else-if="screen === 'session'" class="detail">
      <button type="button" class="back" @click="back">← Back</button>
      <h1>{{ current.title }}</h1>
      <p>Speaker {{ current.speaker }}</p>
      <p>Time {{ current.time }}–{{ current.endTime }}</p>
      <p class="where"><RoomDot :room="current.room" /> {{ current.roomName }}</p>
      <p>Day {{ current.day }}</p>
      <p class="code">{{ codeOf(current) }}</p>
    </article>

    <article v-else class="detail">
      <button type="button" class="back" @click="back">← Back</button>
      <img class="avatar" :src="current.photo" :alt="current.name" />
      <h1>{{ current.name }}</h1>
      <h2>Sessions</h2>
      <p v-for="session in current.sessions" :key="session.id">
        {{ session.title }} — Day {{ session.day }}, {{ session.time }}, <RoomDot :room="session.room" /> {{ session.roomName }}
      </p>
    </article>
  </section>
</template>

<style scoped>
.switch, .days { display: flex; gap: 8px; margin-bottom: 12px; }
button { border: 0; background: #fff; border-radius: 999px; padding: 8px 12px; color: #334155; }
button.on { background: #2563eb; color: #fff; }
.list, .speakers { display: grid; gap: 10px; }
.row, .person { text-align: left; border-radius: 14px; padding: 12px; display: grid; gap: 4px; }
.person { grid-template-columns: 56px 1fr; align-items: center; }
.person img, .avatar { width: 56px; height: 56px; object-fit: cover; border-radius: 50%; }
.avatar { width: 120px; height: 120px; }
.where { display: flex; align-items: center; gap: 6px; }
.back { margin-bottom: 12px; }
.code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  border: 1px dashed #16a34a;
  color: #166534;
  padding: 10px 12px;
  width: fit-content;
}
h1 { font-size: 28px; margin: 0 0 8px; }
@media (min-width: 768px) {
  .speakers { grid-template-columns: 1fr 1fr; }
}
</style>
