<script setup>
import { ref } from 'vue'
import RoomDot from '../components/RoomDot.vue'
import { loadJSON } from '../lib/data.js'
import { errorMessage } from '../lib/ui.js'

const open = ref(false)
const title = ref('')
const sessions = ref([])

const zones = [
  ['room1', 'Room 1', 'z-room1', 'zone-room1'],
  ['room2', 'Room 2', 'z-room2', 'zone-room2'],
  ['room3', 'Room 3', 'z-room3', 'zone-room3'],
  ['room4', 'Room 4', 'z-room4', 'zone-room4'],
  ['hall', 'Hall', 'z-hall', 'zone-hall'],
]

async function show(id, name) {
  errorMessage.value = ''
  title.value = name
  const data = await loadJSON(`api/rooms/${id}/sessions.json`, 'Could not load sessions for this room. Please try again.')
  if (!data) return
  sessions.value = data
  open.value = true
}

function close() {
  open.value = false
}
</script>

<template>
  <section>
    <div class="map">
      <button v-for="zone in zones" :key="zone[0]" type="button" class="zone" :class="zone[2]" :data-testid="zone[3]" @click="show(zone[0], zone[1])">{{ zone[1] }}</button>
      <div class="zone z-public">Public Area</div>
      <div class="zone z-road">Road Show</div>
      <div class="zone z-entr">Entrance</div>
      <div class="zone z-shop">Shop</div>
      <div class="zone z-rest">Restaurant</div>
      <div class="zone corr-h">Corridor</div>
      <div class="zone corr-v">Corridor</div>
    </div>

    <div class="backdrop" :class="{ open }" @click="close"></div>
    <section class="sheet" :class="{ open }" data-testid="room-modal">
      <header>
        <h2>{{ title }}</h2>
        <button type="button" data-testid="modal-close-btn" @click="close">Done</button>
      </header>
      <p v-for="session in sessions" :key="session.id">
        <strong>{{ session.title }}</strong>
        {{ session.speaker }} · {{ session.time }} · Day {{ session.day }}
        <RoomDot :room="session.room" />
      </p>
    </section>
  </section>
</template>

<style scoped>
.map {
  display: grid;
  gap: 8px;
  grid-template-columns: 1fr 1fr;
  grid-template-areas:
    "room1 room1"
    "room2 room2"
    "room3 room3"
    "public road"
    "entr shop"
    "entr rest"
    "hall room4";
}
.zone.corr-h, .zone.corr-v { display: none; }
@media (min-width: 768px) {
  .map {
    grid-template-columns: 1fr 1.5fr 1fr;
    grid-template-areas:
      "room1 room2 room3"
      "corrh corrh road"
      "public corrv road"
      "public entr shop"
      "hall entr rest"
      "hall room4 room4";
  }
  .zone.corr-h, .zone.corr-v { display: grid; }
}
.z-room1 { grid-area: room1; --c: 61 122 232; }
.z-room2 { grid-area: room2; --c: 31 168 135; }
.z-room3 { grid-area: room3; --c: 124 94 199; }
.z-room4 { grid-area: room4; --c: 212 95 132; }
.z-hall { grid-area: hall; --c: 196 138 42; }
.z-public { grid-area: public; --c: 109 132 168; }
.z-road { grid-area: road; --c: 42 155 184; }
.z-entr { grid-area: entr; --c: 138 153 176; }
.z-shop { grid-area: shop; --c: 138 153 176; }
.z-rest { grid-area: rest; --c: 138 153 176; }
.corr-h { grid-area: corrh; --c: 138 153 176; }
.corr-v { grid-area: corrv; --c: 138 153 176; }
.zone {
  background: rgb(var(--c) / .13);
  border: 1px solid rgb(var(--c) / .45);
  color: color-mix(in srgb, rgb(var(--c)) 70%, #000);
  border-radius: 10px;
  display: grid;
  place-items: center;
  min-height: 72px;
  font-weight: 750;
  font-size: 13px;
}
button.zone { width: 100%; }
.backdrop {
  position: fixed;
  inset: 0;
  background: rgb(0 0 0 / .35);
  opacity: 0;
  pointer-events: none;
  transition: opacity .3s;
}
.backdrop.open { opacity: 1; pointer-events: auto; }
.sheet {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 50;
  background: #fff;
  border-radius: 16px 16px 0 0;
  padding: 16px 16px 80px;
  transform: translateY(100%);
  visibility: hidden;
  transition: transform .3s ease, visibility 0s .3s;
}
.sheet.open { transform: translateY(0); visibility: visible; transition: transform .3s ease; }
.sheet header { display: flex; justify-content: space-between; align-items: center; }
@media (prefers-reduced-motion: reduce) {
  .sheet, .sheet.open, .backdrop, .backdrop.open { transition: none; }
}
</style>
