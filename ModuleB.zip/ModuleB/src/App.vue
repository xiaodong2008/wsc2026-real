<script setup>
import { RouterView } from 'vue-router'
import BottomNav from './components/BottomNav.vue'
import { errorMessage } from './lib/ui.js'
</script>

<template>
  <div class="app">
    <header>
      <p>Mobile Conference</p>
    </header>
    <p class="error" data-testid="error-message">{{ errorMessage }}</p>
    <main>
      <RouterView />
    </main>
    <BottomNav />
  </div>
</template>

<style>
:root { color-scheme: light; }
* { box-sizing: border-box; }
html, body { margin: 0; }
body {
  font-family: ui-sans-serif, system-ui, sans-serif;
  background: #f6f7fb;
  color: #142033;
}
button, input { font: inherit; }
button { cursor: pointer; }
.app { min-height: 100vh; }
header {
  height: 52px;
  display: flex;
  align-items: center;
  padding: 0 16px;
  background: #fff;
  border-bottom: 1px solid #e4e8f0;
}
header p { margin: 0; font-weight: 750; }
.error {
  margin: 0;
  padding: 0 16px;
  color: #9f1239;
  font-weight: 650;
}
.error:empty { display: none; }
main {
  height: calc(100vh - 52px);
  overflow: auto;
  padding: 12px 16px 88px;
}
</style>
