<script setup>
import { RouterLink } from 'vue-router'
</script>

<template>
  <nav class="bar" aria-label="Sections">
    <RouterLink to="/schedule" data-testid="nav-schedule">Schedule</RouterLink>
    <RouterLink to="/map" data-testid="nav-map">Map</RouterLink>
    <RouterLink to="/stamps" data-testid="nav-stamps">Stamps</RouterLink>
    <RouterLink to="/photo" data-testid="nav-photo">Photo</RouterLink>
  </nav>
</template>

<style scoped>
.bar {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 20;
  height: 64px;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  background: #fff;
  border-top: 1px solid #e4e8f0;
}
a {
  display: grid;
  place-items: center;
  color: #5c6b82;
  text-decoration: none;
  font-weight: 650;
  font-size: 13px;
}
a.router-link-active {
  color: #2563eb;
}
</style>
