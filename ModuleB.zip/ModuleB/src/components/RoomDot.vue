<script setup>
import { dotStyle } from '../lib/venue.js'

defineProps({
  room: { type: String, required: true },
})
</script>

<template>
  <span class="dot" :style="dotStyle(room)" aria-hidden="true"></span>
</template>

<style scoped>
.dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  display: inline-block;
  flex: 0 0 auto;
}
</style>
